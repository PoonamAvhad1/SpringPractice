package com.yash.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.yash.entity.Student;
import com.yash.integrate.ConnectionManager;

public class JBDCStudentDAOImpl implements StudentDAO {

	@Override
	public List<Student> getAllStudent() throws ClassNotFoundException, SQLException {
		
		Connection connection=ConnectionManager.openConnection();
		Statement statement=connection.createStatement();
		ResultSet resultSet=statement.executeQuery("select * from student");
		List<Student> studentList=new ArrayList<>();
		
		while(resultSet.next()){
			
			Student student=new Student();
			student.setRollNo(resultSet.getInt("roll_no"));
			student.setStudentName(resultSet.getString("student_name"));
			student.setStudentAddress(resultSet.getString("student_address"));
			studentList.add(student);			
		}
		ConnectionManager.closeConnection();
		
		System.out.println(studentList);
		return studentList;
	}

}
