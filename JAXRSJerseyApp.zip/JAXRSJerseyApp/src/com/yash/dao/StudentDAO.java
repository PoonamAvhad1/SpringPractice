package com.yash.dao;

import java.sql.SQLException;
import java.util.List;

import com.yash.entity.Student;

public interface StudentDAO {

	public List<Student> getAllStudent()throws ClassNotFoundException, SQLException;
}
