package com.yash.controller;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.yash.entity.Student;
import com.yash.factory.FactoryStudent;
import com.yash.service.StudentService;

@Path("/student-app")
public class StudentController {

	private StudentService studentService=null;
	
	public StudentController(){
		this.studentService=FactoryStudent.createStudentService();
		
	}
	
	@GET
	@Path("/students")
	@Produces(MediaType.APPLICATION_XML)
	public List<Student> getAllStudents_xml(){
				List<Student> studentList=studentService.studentRetrivalService();
		return studentList;
		
		
		
	}
	
}
