package com.yash.integrate;

import java.util.ResourceBundle;

public class DataSource {

	private String url;
	private String driver;
	private String username;
	private String password;
	public DataSource(String basename) {
	
	ResourceBundle resourceBundle=ResourceBundle.getBundle(basename);
	this.driver=resourceBundle.getString("driver");
	this.url=resourceBundle.getString("url");
	this.password=resourceBundle.getString("password");
	this.username=resourceBundle.getString("username");
	
	
	}
	public String getUrl() {
		return url;
	}
	public String getDriver() {
		return driver;
	}
	public String getUsername() {
		return username;
	}
	public String getPassword() {
		return password;
	}
	
}
