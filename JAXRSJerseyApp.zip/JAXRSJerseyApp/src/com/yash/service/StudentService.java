package com.yash.service;

import java.util.List;

import com.yash.entity.Student;

public interface StudentService {

	public List<Student> studentRetrivalService();
}
