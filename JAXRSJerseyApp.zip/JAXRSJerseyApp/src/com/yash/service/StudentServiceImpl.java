package com.yash.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.yash.dao.StudentDAO;
import com.yash.entity.Student;
import com.yash.factory.FactoryStudent;

public class StudentServiceImpl implements StudentService{

	private StudentDAO studentDAO=null;
	
	public StudentServiceImpl() {
	
	this.studentDAO=FactoryStudent.createStudentDAO();
	}
	
	@Override
	public List<Student> studentRetrivalService() {
		// TODO Auto-generated method stub
		
		List<Student> studentList= new ArrayList<>();
		
		try {
			studentList=studentDAO.getAllStudent();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return studentList;
	}
	
	
	
}
