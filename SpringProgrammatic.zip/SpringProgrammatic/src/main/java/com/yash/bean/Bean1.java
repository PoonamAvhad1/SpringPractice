package com.yash.bean;

public class Bean1 {

	public Bean1(){
		System.out.println("---bean1---");
	}

	public void x(){
		System.out.println("---x---");
	}
}

