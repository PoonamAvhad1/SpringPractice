package com.yash.bean;

public class NonSpringBean {
	
	private int a;

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}
	

}
