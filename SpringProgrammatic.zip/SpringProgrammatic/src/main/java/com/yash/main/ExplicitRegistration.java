package com.yash.main;

import org.springframework.beans.MutablePropertyValues;
import org.springframework.beans.factory.config.ConstructorArgumentValues;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.beans.factory.support.GenericBeanDefinition;

import com.yash.bean.NonSpringBean;

public class ExplicitRegistration {

	public static void main(String[] args) {
		DefaultListableBeanFactory registry=new DefaultListableBeanFactory();
		GenericBeanDefinition beanDefn=new GenericBeanDefinition();
		beanDefn.setBeanClass(NonSpringBean.class);
		
		/*ConstructorArgumentValues constructorArgumentValues=new ConstructorArgumentValues();
		constructorArgumentValues.addIndexedArgumentValue(0, new Object(),"int");
		beanDefn.setConstructorArgumentValues(constructorArgumentValues);*/
		
		MutablePropertyValues propertyValues=new MutablePropertyValues();
		propertyValues.add("a", 10);
		beanDefn.setPropertyValues(propertyValues);
		registry.registerBeanDefinition("nonspring", beanDefn);
		
		NonSpringBean nonSpringBean=(NonSpringBean)registry.getBean("nonspring");
		System.out.println(nonSpringBean.getA());
		
		
		
		
		
		
	}
}
