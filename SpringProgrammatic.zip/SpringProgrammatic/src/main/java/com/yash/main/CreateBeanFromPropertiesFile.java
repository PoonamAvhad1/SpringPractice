package com.yash.main;

import org.springframework.beans.factory.support.PropertiesBeanDefinitionReader;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.core.io.ClassPathResource;

import com.yash.bean.YashBean;

public class CreateBeanFromPropertiesFile {

	public static void main(String[] args) {
		
		GenericApplicationContext ctx=new GenericApplicationContext();
		
		PropertiesBeanDefinitionReader pReader=new PropertiesBeanDefinitionReader(ctx);
		pReader.loadBeanDefinitions(new ClassPathResource("bean.properties"));
		ctx.refresh();
		
		YashBean yashBean=(YashBean)ctx.getBean("yashbean");
		System.out.println("a"+yashBean.getA());
		
	}
	
}
