package com.yash.main;

import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.core.io.ClassPathResource;

import com.yash.bean.Bean1;

public class ExplicitlyLoadBeanDefinition {

	public static void main(String[] args) {
		GenericApplicationContext applicationContext= new GenericApplicationContext();
		XmlBeanDefinitionReader xmReader=new XmlBeanDefinitionReader(applicationContext);
		xmReader.loadBeanDefinitions(new ClassPathResource("applicationContext.xml"));
		applicationContext.refresh();
		
		Bean1  bean1=(Bean1)applicationContext.getBean("bean1");
		bean1.x();
	}
	
}
