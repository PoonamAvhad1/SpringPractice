package com.yash.proxy;

public class MyClass {

	public String  x(String str){
		return str;
	}
	
}
