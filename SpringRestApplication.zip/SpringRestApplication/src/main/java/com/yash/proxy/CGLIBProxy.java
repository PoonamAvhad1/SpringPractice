package com.yash.proxy;

import net.sf.cglib.proxy.Enhancer;
import net.sf.cglib.proxy.FixedValue;

public class CGLIBProxy {

	public static void main(String[] args) {
		
		Enhancer enhancer=new Enhancer();
		enhancer.setSuperclass(MyClass.class);
		enhancer.setCallback(new FixedValue() {
			
			@Override
			public Object loadObject() throws Exception {
				// TODO Auto-generated method stub
				return "sabbir";
			}
		});
		
		
		MyClass proxy=(MyClass)enhancer.create();
		
		String result=proxy.x("java");
		System.out.println("Result:"+result);
	
		Enhancer enhancer1=new Enhancer();
		enhancer.setSuperclass(MyInterface.class);
		enhancer.setCallback(new FixedValue() {
			
			@Override
			public Object loadObject() throws Exception {
				// TODO Auto-generated method stub
				return "sabbir";
			}
		});
		MyInterface myInterface=(MyInterface)enhancer.create();
		
		String result1=myInterface.y(null);
		System.out.println("Result:"+result1);
	
	}
	
}
