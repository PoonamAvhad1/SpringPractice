package com.yash.model;

import com.yash.custom.CustomHttpStatus;

public class StudentError {
	
	private CustomHttpStatus errorCode;
	private String errorMessage;
	
	public StudentError() {
		// TODO Auto-generated constructor stub
	}

	public CustomHttpStatus getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(CustomHttpStatus validationFailed) {
		this.errorCode = validationFailed;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	

}
