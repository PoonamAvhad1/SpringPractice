package com.yash.service;

import java.util.List;

import com.yash.model.StudentRequest;
import com.yash.model.StudentResponse;

public interface StudentService {

	public List<StudentResponse> studentRetrievalService();
	
	public StudentResponse studentRetrievalServiceRollNo(int rollno);
	
	public boolean studentRegistrationService(StudentRequest studRequest);
}
