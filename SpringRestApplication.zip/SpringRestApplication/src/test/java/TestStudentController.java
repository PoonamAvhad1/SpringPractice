import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MockMvcBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;

import com.yash.controller.StudentController;
import com.yash.model.StudentError;
import com.yash.model.StudentRegisterResponse;
import com.yash.model.StudentRequest;
import com.yash.model.StudentResponse;
import com.yash.service.StudentService;
import com.yash.service.StudentServiceImpl;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"classpath:applicationContext.xml"})
public class TestStudentController {

	private MockMvc mockMvc;
	
	@Mock
	private StudentService studentService;
	
	
	@InjectMocks
	private StudentController studentController;
	
		
	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
		mockMvc=MockMvcBuilders
				.standaloneSetup(studentController)
				.build();
	}
	
	@Test
	public void testRetrievalAllStudents_positive(){
		try
		{
		List<StudentResponse> studentResponsesList=new ArrayList<StudentResponse>();
		StudentResponse studentResponse=new StudentResponse();
		studentResponse.setRollno(1001);
		studentResponse.setName("Poonam");
		studentResponse.setAddress("sangvi");
		
		studentResponsesList.add(studentResponse);
		
		when(studentService.studentRetrievalService()).thenReturn(studentResponsesList);
		
		ResponseEntity<List<StudentResponse>> response=studentController.retriveAllStudent();
		
		List<StudentResponse> studentList=response.getBody();
		
		assertEquals(true, studentList.size()>0);
		
	}
		catch(NullPointerException e){
			assertTrue(false);
		}
		
		
	}
	
	
	@Test
	public void test_retrieveAllStudents_positive_data_test(){
		try{
			List<StudentResponse> studentResponsesList=new ArrayList<StudentResponse>();
			StudentResponse studentResponse=new StudentResponse();
			studentResponse.setRollno(1001);
			studentResponse.setName("Poonam");
			studentResponse.setAddress("sangvi");
			
			studentResponsesList.add(studentResponse);
			
			when(studentService.studentRetrievalService()).thenReturn(studentResponsesList);
			
			ResponseEntity<List<StudentResponse>> response=studentController.retriveAllStudent();
			
			List<StudentResponse> studentList=response.getBody();
			
			assertEquals(1001, studentList.get(0).getRollno());
			
			
			
		}catch(IndexOutOfBoundsException e){
			assertTrue(false);
		}
	}
	
	
	
	@Test
	public void test_retrieveAllStudents_negative(){
		
		List<StudentResponse> studentResponsesList=new ArrayList<StudentResponse>();
		
		when(studentService.studentRetrievalService()).thenReturn(studentResponsesList);
		ResponseEntity<List<StudentResponse>> response=studentController.retriveAllStudent();
		List<StudentResponse> studentList=response.getBody();
		StudentResponse studentResponse=new StudentResponse();
		studentResponse.setRollno(1001);
		studentResponse.setName("Poonam");
		studentResponse.setAddress("sangvi");
		
		
		try{
			when(studentList.get(0).getRollno()==studentResponse.getRollno());
			assertTrue(false);
		}
		catch(IndexOutOfBoundsException e){
			assertTrue(true);
		}
		
		
	}
	

	
	@Test
	public void test_persistStudent_positive(){
		
		try{
		
			StudentRequest studentRequest=new StudentRequest();
			studentRequest.setRollno(11118);
			studentRequest.setName("poonam");
			studentRequest.setAddress("abcjjh");
			
			Errors errors=new BeanPropertyBindingResult(studentRequest, "studentRequest");
			
			when(studentService.studentRegistrationService(studentRequest)).thenReturn(true);
			
			ResponseEntity<StudentRegisterResponse> response=studentController.persistStudent(studentRequest, errors);
			
			StudentRegisterResponse studentRegisterResponse=response.getBody();
			
			assertEquals("registered",studentRegisterResponse.getResponseMessage());
			
		}catch(Exception e){
			assertTrue(false);
		}
		
	}
	
	
	
	@Test
	public void test_persistStudent_negative(){
		
		try{
		
			StudentRequest studentRequest=new StudentRequest();
			studentRequest.setRollno(11118);
			studentRequest.setName("poonam");
			studentRequest.setAddress("abcjjh");
			
			Errors errors=new BeanPropertyBindingResult(studentRequest, "studentRequest");
			Errors mock=Mockito.mock(Errors.class);
			when(mock.hasErrors()).thenReturn(true);
			when(studentService.studentRegistrationService(studentRequest)).thenReturn(false);
			
			ResponseEntity<StudentRegisterResponse> response=studentController.persistStudent(studentRequest, errors);
			
			StudentRegisterResponse studentRegisterResponse=response.getBody();
			
			assertEquals(" not registered",studentRegisterResponse.getResponseMessage());
			
		}catch(Exception e){
			assertTrue(false);
		}
		
	}
	
	@Test
	public void test_persistStudent_positive_validation(){
		
		try{
		
 			StudentRequest studentRequest=new StudentRequest();
			studentRequest.setRollno(11118);
			studentRequest.setName("poonam");
			studentRequest.setAddress("abcjjh");
			
			Errors mock=Mockito.mock(Errors.class);
			when(mock.hasErrors()).thenReturn(true);
			
			List<ObjectError> objectErrorList=new ArrayList<>();
			ObjectError objectError=new ObjectError("validation error"," student name cannot be blank");
			objectErrorList.add(objectError);
			when(mock.getAllErrors()).thenReturn(objectErrorList);
			when(studentService.studentRegistrationService(studentRequest)).thenReturn(false);
			
			ResponseEntity<StudentRegisterResponse> response=studentController.persistStudent(studentRequest, mock);
			
			StudentRegisterResponse studentRegisterResponse=response.getBody();
			
			assertEquals("validation error",studentRegisterResponse.getResponseMessage());
			List<StudentError> studentErrors=studentRegisterResponse.getStudentError();
			
			assertEquals(true,studentErrors.size()>0);
			
			
		}catch(Exception e){
			assertTrue(false);
		}
		
	}
}
