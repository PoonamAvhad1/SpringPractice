package com.yash.handler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.ResponseErrorHandler;

public class StudentErrorHandler implements ResponseErrorHandler{

	List<HttpStatus> status=new ArrayList<HttpStatus>();

	public boolean checkStatusCode(ClientHttpResponse response) throws IOException{

		int statusCode=response.getStatusCode().value();
		boolean result=false;
		switch (statusCode) {
		case  400:

			result=true;
			break;

		

		default:
			result=false;
			break;
		}

		return result;
	}

	@Override
	public boolean hasError(ClientHttpResponse response) throws IOException {
		// TODO Auto-generated method stub


		return false;
	}

	@Override
	public void handleError(ClientHttpResponse response) throws IOException {


		System.out.println("status code:"+response.getStatusCode());
	}

}
