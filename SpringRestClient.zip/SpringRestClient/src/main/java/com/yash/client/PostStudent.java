package com.yash.client;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.ResponseErrorHandler;
import org.springframework.web.client.RestTemplate;

import com.yash.handler.StudentErrorHandler;
import com.yash.model.StudentError;
import com.yash.model.StudentRegisterResponse;
import com.yash.model.StudentRequest;

public class PostStudent {
public static void main(String[] args) {
	
	RestTemplate template=new RestTemplate();
	
	template.setErrorHandler(new StudentErrorHandler());
	StudentRequest studentRequest=new StudentRequest();
	studentRequest.setRollno(1900);
	studentRequest.setName("Rajesh");
	studentRequest.setAddress("Amanora");
	
	HttpHeaders headers=new HttpHeaders();
	headers.setContentType(MediaType.APPLICATION_JSON);
	
	HttpEntity<String> requestEntity=new HttpEntity<String>(headers);
	
	String url="http://localhost:8082/student-app/students";
	
	StudentRegisterResponse response=template.postForObject(url,studentRequest, StudentRegisterResponse.class);
	
	System.out.println("message:"+response.getResponseMessage());
	
	
	List<StudentError> studentErrorList=response.getStudentError();
	
	for(StudentError studentError:studentErrorList){
		System.out.println(studentError);
		System.out.println(studentError.getErrorMessage());
	}
	
	
	
}
}
